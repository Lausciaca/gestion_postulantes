from setuptools import setup, find_packages

setup(
    name='gestion_postulantes',  # Reemplaza con el nombre de tu aplicación
    version='1.0.0',
    packages=find_packages(),  # Encuentra todos los paquetes en el directorio
    include_package_data=True,
    install_requires=[
        'Django==4.2',  # Asegúrate de especificar la versión de Django
        # Otras dependencias que tu app pueda requerir
    ],
    description='Descripción de tu aplicación',
    author='Tu nombre',
    author_email='tu_email@example.com',
    url='https://tu-url-de-repo-o-pagina.com',
)
