from django.db import models

# Create your models here.
class Postulante(models.Model):
    nombre = models.CharField( max_length=50)
    apellido = models.CharField( max_length=50)
    dni = models.IntegerField()
    cuil = models.IntegerField()
    fechaDeNacimiento = models.DateField( auto_now=False, auto_now_add=False)
    estadoCivil = models.CharField( max_length=50)
    hijos = models.IntegerField()
    telefonoCelular = models.IntegerField()
    telefonoFijo = models.IntegerField()
    email = models.EmailField( max_length=254)
    domicilio = models.CharField( max_length=50)
    barrio = models.CharField( max_length=50)
    discapacidad = models.BooleanField()
    certificadoDiscapacidad = models.FileField( upload_to=None, max_length=100)
    escolaridadMaxima = models.CharField( max_length=50)
    foto = models.ImageField( upload_to=None, height_field=None, width_field=None, max_length=None)

    # capacitacion
    HORARIOS = [
        ('Mañana', 'mañana'),
        ('Tarde', 'tarde'),
        ('Jornada completa', 'jornada completa')
    ]
    interesCapacitacion = models.BooleanField()
    cursosDeInteres = models.JSONField()
    disponibilidadHoraria = models.CharField( choices=HORARIOS, max_length=50)
    rubrosPostuladosSinExperiencia = models.JSONField()

    # conocimientos
    conocimientosInformatica = models.BooleanField()
    textoInformatica = models.TextField()
    certificadoInformatica = models.FileField( upload_to=None, max_length=100)
    conocimientosIdiomas = models.BooleanField()
    textoIdiomas = models.TextField()
    certificadoIdiomas = models.FileField( upload_to=None, max_length=100)

    # formacion virtual
    poseeCelular = models.BooleanField()
    poseeComputadora = models.BooleanField()
    conectividadWifi = models.BooleanField()
    interesCapacitacion = models.BooleanField() 


    def __str__(self):
        return f"{self.nombre} {self.apellido}"
    

class Licencia(models.Model):
    LICENCIAS = [
        ('A 1.1', 'A 1.1'),
        ('A 1.2', 'A 1.2'),
        ('A 1.3', 'A 1.3'),
        ('A 1.4', 'A 1.4'),
        ('A 2.1', 'A 2.1'),
        ('A 2.2', 'A 2.2'),
        ('A 3', 'A 3'),
        ('B 1', 'B 1'),
        ('B 2', 'B 2'),
        ('C 1', 'C 1'),
        ('C 2', 'C 2'),
        ('C 3', 'C 3'),
        ('D 1', 'D 1'),
        ('D 2', 'D 2'),
        ('D 3', 'D 3'),
        ('D 4', 'D 4'),
        ('E 1', 'E 1'),
        ('E 2', 'E 2'),
        ('F', 'F'),
        ('G 1', 'G 1'),
        ('G 2', 'G 2'),
        ('G 3', 'G 3'),
    ]
    posee = models.BooleanField()
    tipoLicencia = models.CharField(choices=LICENCIAS, max_length=50)
    fechaVencimiento = models.DateField(auto_now=False, auto_now_add=False)
    postulante = models.ForeignKey('Postulante', on_delete=models.CASCADE, related_name='licencias')


class Educacion(models.Model):
    institucion = models.CharField( max_length=50)
    terminalidad = models.CharField( max_length=50)
    finalizacion = models.DateField( auto_now=False, auto_now_add=False)
    certificado = models.FileField( upload_to=None, max_length=100)
    observaciones = models.TextField()
    postulante = models.ForeignKey(Postulante, on_delete=models.CASCADE, related_name='educacion')


class Curso (models.Model):
    institucion = models.CharField( max_length=50)
    nombreCurso = models.CharField( max_length=50)
    fechaRealizacion = models.DateField( auto_now=False, auto_now_add=False)
    certificado = models.FileField( upload_to=None, max_length=100)
    postulante = models.ForeignKey(Postulante, on_delete=models.CASCADE, related_name='cursos')


class experienciaLaboral(models.Model):
    fechaIngreso = models.DateField( auto_now=False, auto_now_add=False)
    fechaEgreso = models.DateField( auto_now=False, auto_now_add=False)
    empresa = models.CharField( max_length=50)
    puesto = models.CharField( max_length=50)
    tareas = models.TextField()
    motivoDesvinculacion = models.TextField()
    numeroReferencias = models.IntegerField()
    interesPuestoSimilar = models.BooleanField()
    postulante = models.ForeignKey(Postulante, on_delete=models.CASCADE, related_name='experienciasLaborales')


class trabajoIndependiente(models.Model):
    fechaInicio = models.DateField( auto_now=False, auto_now_add=False)
    fechaFin = models.DateField( auto_now=False, auto_now_add=False)
    lugar = models.TextField()
    actividad = models.TextField()
    interesPuestoSimilar = models.BooleanField()
    postulante = models.ForeignKey(Postulante, on_delete=models.CASCADE, related_name='trabajosIndependientes')
